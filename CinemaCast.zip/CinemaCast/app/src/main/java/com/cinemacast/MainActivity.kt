package com.cinemacast

import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.MediaSeekOptions
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import fi.iki.elonen.NanoHTTPD
import java.net.Inet4Address

class MainActivity : AppCompatActivity() {

    private lateinit var castContext: CastContext
    private lateinit var status: TextView
    private var server: FileServer? = null
    private var url: String? = null
    private var title: String = ""
    private var mime: String = "video/mp4"

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onPicked(uri)
    }

    private val sessionListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarted(s: CastSession, id: String) { loadOnCast() }
        override fun onSessionStarting(s: CastSession) {}
        override fun onSessionStartFailed(s: CastSession, error: Int) {
            status.text = "Falha ao conectar na TV (código $error)"
        }
        override fun onSessionEnding(s: CastSession) {}
        override fun onSessionEnded(s: CastSession, error: Int) {
            status.text = "Desconectado da TV"
        }
        override fun onSessionResuming(s: CastSession, id: String) {}
        override fun onSessionResumed(s: CastSession, wasSuspended: Boolean) {}
        override fun onSessionResumeFailed(s: CastSession, error: Int) {}
        override fun onSessionSuspended(s: CastSession, reason: Int) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        castContext = CastContext.getSharedInstance(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 120, 48, 48)
        }

        val route = MediaRouteButton(this)
        CastButtonFactory.setUpMediaRouteButton(applicationContext, route)
        root.addView(route, LinearLayout.LayoutParams(160, 160))

        status = TextView(this).apply {
            text = "1) Escolha o filme  2) Toque no ícone de TV e escolha a TV"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 32, 0, 32)
        }
        root.addView(status)

        root.addView(button("Escolher filme da galeria") { picker.launch(arrayOf("video/*")) })
        root.addView(button("Play / Pausa") { remote()?.togglePlayback() })
        root.addView(button("Voltar 10s") { seekBy(-10_000) })
        root.addView(button("Avançar 10s") { seekBy(10_000) })
        root.addView(button("Parar transmissão") { castContext.sessionManager.endCurrentSession(true) })

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        castContext.sessionManager.addSessionManagerListener(sessionListener, CastSession::class.java)
    }

    override fun onPause() {
        castContext.sessionManager.removeSessionManagerListener(sessionListener, CastSession::class.java)
        super.onPause()
    }

    override fun onDestroy() {
        server?.stop()
        super.onDestroy()
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 16 }
    }

    private fun remote() = castContext.sessionManager.currentCastSession?.remoteMediaClient

    private fun seekBy(deltaMs: Long) {
        val r = remote() ?: return
        val pos = (r.approximateStreamPosition + deltaMs).coerceAtLeast(0L)
        r.seek(MediaSeekOptions.Builder().setPosition(pos).build())
    }

    private fun localIp(): String? {
        val cm = getSystemService(ConnectivityManager::class.java)
        val lp = cm.getLinkProperties(cm.activeNetwork) ?: return null
        return lp.linkAddresses
            .map { it.address }
            .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
            ?.hostAddress
    }

    private fun onPicked(uri: Uri) {
        var size = 0L
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val s = c.getColumnIndex(OpenableColumns.SIZE)
                if (n >= 0) title = c.getString(n)
                if (s >= 0) size = c.getLong(s)
            }
        }
        mime = contentResolver.getType(uri) ?: "video/mp4"

        val ip = localIp()
        if (ip == null) {
            status.text = "Conecte o celular no Wi-Fi da TV"
            return
        }

        server?.stop()
        server = FileServer(this, PORT).also {
            it.src = uri
            it.mimeType = mime
            it.length = size
            it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
        }
        url = "http://$ip:$PORT/video"
        status.text = "Pronto: $title\nToque no ícone de TV e escolha a TV."
        loadOnCast()
    }

    private fun loadOnCast() {
        val u = url ?: return
        val r = remote() ?: return
        val meta = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE).apply {
            putString(MediaMetadata.KEY_TITLE, title)
        }
        val info = MediaInfo.Builder(u)
            .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
            .setContentType(mime)
            .setMetadata(meta)
            .build()
        r.load(MediaLoadRequestData.Builder().setMediaInfo(info).setAutoplay(true).build())
        status.text = "Transmitindo: $title"
    }

    companion object {
        private const val PORT = 8765
    }
}
