package com.cinemacast

import android.content.Context
import android.net.Uri
import fi.iki.elonen.NanoHTTPD
import java.io.FileInputStream
import java.io.FilterInputStream

/** Serve o video escolhido na galeria pela rede Wi-Fi, com suporte a Range (pular no filme). */
class FileServer(private val ctx: Context, port: Int) : NanoHTTPD(port) {

    var src: Uri? = null
    var mimeType: String = "video/mp4"
    var length: Long = 0L

    override fun serve(session: IHTTPSession): Response {
        val u = src ?: return NanoHTTPD.newFixedLengthResponse(
            Response.Status.NOT_FOUND, MIME_PLAINTEXT, "sem arquivo"
        )
        val total = length
        val range = session.headers["range"]

        var start = 0L
        var end = total - 1
        if (range != null && range.startsWith("bytes=")) {
            val parts = range.removePrefix("bytes=").split("-")
            start = parts.getOrNull(0)?.toLongOrNull() ?: 0L
            parts.getOrNull(1)?.toLongOrNull()?.let { end = it.coerceAtMost(total - 1) }
        }
        if (start >= total) {
            val r = NanoHTTPD.newFixedLengthResponse(
                Response.Status.RANGE_NOT_SATISFIABLE, MIME_PLAINTEXT, ""
            )
            r.addHeader("Content-Range", "bytes */$total")
            return r
        }

        val pfd = ctx.contentResolver.openFileDescriptor(u, "r")
            ?: return NanoHTTPD.newFixedLengthResponse(
                Response.Status.NOT_FOUND, MIME_PLAINTEXT, "nao abriu"
            )
        val fis = FileInputStream(pfd.fileDescriptor)
        fis.channel.position(start)
        val stream = object : FilterInputStream(fis) {
            override fun close() {
                super.close()
                pfd.close()
            }
        }

        val len = end - start + 1
        val status = if (range != null) Response.Status.PARTIAL_CONTENT else Response.Status.OK
        val resp = NanoHTTPD.newFixedLengthResponse(status, mimeType, stream, len)
        resp.addHeader("Accept-Ranges", "bytes")
        resp.addHeader("Access-Control-Allow-Origin", "*")
        if (range != null) resp.addHeader("Content-Range", "bytes $start-$end/$total")
        return resp
    }
}
