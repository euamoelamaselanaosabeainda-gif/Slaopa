package com.cinemacast

import android.net.Uri
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

/** Legenda externa carregada pelo usuário. [path] só existe se dá para mandar para a TV (WebVTT). */
data class ExtSub(
    val id: Long,
    val name: String,
    val uri: Uri,
    val mime: String,
    val path: String?
)

object Subs {

    /** Lê bytes de legenda em UTF-8, UTF-16 ou Windows-1252 (comum em .srt em português). */
    fun decode(bytes: ByteArray): String {
        var b = bytes
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte()) {
            b = b.copyOfRange(3, b.size)
        } else if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) {
            return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        } else if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte()) {
            return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        }
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(b))
                .toString()
        } catch (e: CharacterCodingException) {
            String(b, Charset.forName("windows-1252"))
        }
    }

    /** SRT -> WebVTT (a TV só entende WebVTT). */
    fun srtToVtt(srt: String): String {
        val ts = Regex("(\\d{1,2}:\\d{2}:\\d{2}),(\\d{3})")
        val sb = StringBuilder("WEBVTT\n\n")
        srt.replace("\r\n", "\n").replace('\r', '\n').lines().forEach { line ->
            sb.append(if (line.contains("-->")) ts.replace(line, "$1.$2") else line).append('\n')
        }
        return sb.toString()
    }
}
