package com.cinemacast

import android.content.Context
import android.net.Uri
import fi.iki.elonen.NanoHTTPD
import java.io.FileInputStream
import java.io.FilterInputStream
import java.util.concurrent.ConcurrentHashMap

/**
 * Serve pela rede Wi-Fi o vídeo escolhido na galeria (com suporte a Range, para pular no filme)
 * e as legendas em WebVTT (/sub/ID.vtt) para a TV.
 */
class FileServer(private val ctx: Context, port: Int) : NanoHTTPD(port) {

    var src: Uri? = null
    var mimeType: String = "video/mp4"
    var length: Long = 0L

    /** caminho (ex.: /sub/3.vtt) -> conteúdo WebVTT */
    val subs = ConcurrentHashMap<String, String>()

    private fun cors(r: Response): Response {
        r.addHeader("Access-Control-Allow-Origin", "*")
        r.addHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
        r.addHeader("Access-Control-Allow-Headers", "Range, Content-Type")
        r.addHeader("Access-Control-Expose-Headers", "Content-Range, Accept-Ranges, Content-Length")
        return r
    }

    override fun serve(session: IHTTPSession): Response {
        if (session.method == Method.OPTIONS) {
            return cors(NanoHTTPD.newFixedLengthResponse(Response.Status.OK, MIME_PLAINTEXT, ""))
        }
        val path = session.uri
        if (path.startsWith("/sub/")) {
            val vtt = subs[path] ?: return cors(
                NanoHTTPD.newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "sem legenda")
            )
            return cors(NanoHTTPD.newFixedLengthResponse(Response.Status.OK, "text/vtt; charset=utf-8", vtt))
        }
        return cors(serveVideo(session))
    }

    private fun serveVideo(session: IHTTPSession): Response {
        val u = src ?: return NanoHTTPD.newFixedLengthResponse(
            Response.Status.NOT_FOUND, MIME_PLAINTEXT, "sem arquivo"
        )
        val total = length
        val range = session.headers["range"]

        var start = 0L
        var end = total - 1
        if (range != null && range.startsWith("bytes=")) {
            val parts = range.removePrefix("bytes=").split("-")
            start = parts.getOrNull(0)?.toLongOrNull() ?: 0L
            parts.getOrNull(1)?.toLongOrNull()?.let { end = it.coerceAtMost(total - 1) }
        }
        if (start >= total) {
            val r = NanoHTTPD.newFixedLengthResponse(
                Response.Status.RANGE_NOT_SATISFIABLE, MIME_PLAINTEXT, ""
            )
            r.addHeader("Content-Range", "bytes */$total")
            return r
        }

        val pfd = ctx.contentResolver.openFileDescriptor(u, "r")
            ?: return NanoHTTPD.newFixedLengthResponse(
                Response.Status.NOT_FOUND, MIME_PLAINTEXT, "nao abriu"
            )
        val fis = FileInputStream(pfd.fileDescriptor)
        fis.channel.position(start)
        val stream = object : FilterInputStream(fis) {
            override fun close() {
                super.close()
                pfd.close()
            }
        }

        val len = end - start + 1
        val status = if (range != null) Response.Status.PARTIAL_CONTENT else Response.Status.OK
        val resp = NanoHTTPD.newFixedLengthResponse(status, mimeType, stream, len)
        resp.addHeader("Accept-Ranges", "bytes")
        if (range != null) resp.addHeader("Content-Range", "bytes $start-$end/$total")
        return resp
    }
}
