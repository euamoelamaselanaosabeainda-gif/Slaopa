package com.cinemacast

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer
import java.util.Locale

/**
 * Passa o filme (ex.: MKV) para MP4 SEM recodificar: copia as amostras de vídeo e de áudio
 * como estão, só trocando a embalagem. Por isso não perde qualidade.
 *
 * Limites do MP4 do Android: vídeo H.264/H.265 e áudio AAC.
 */
object Remuxer {

    data class Audio(val track: Int, val label: String, val supported: Boolean)

    data class Info(
        val videoTrack: Int,
        val videoOk: Boolean,
        val videoMime: String,
        val audios: List<Audio>
    )

    private val VIDEO_OK = setOf("video/avc", "video/hevc")
    private const val AUDIO_OK = "audio/mp4a-latm"

    private fun label(f: MediaFormat, n: Int): String {
        val lang = if (f.containsKey(MediaFormat.KEY_LANGUAGE)) f.getString(MediaFormat.KEY_LANGUAGE) else null
        val name = lang
            ?.takeIf { it.isNotBlank() && it != "und" }
            ?.let { Locale.forLanguageTag(it).getDisplayLanguage(Locale("pt", "BR")) }
            ?.takeIf { it.isNotBlank() }
            ?.replaceFirstChar { it.uppercase() }
            ?: "Áudio $n"
        val ch = if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) f.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 0
        val extra = when {
            ch >= 8 -> " · 7.1"
            ch >= 6 -> " · 5.1"
            else -> ""
        }
        val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
        val codec = when (mime) {
            "audio/mp4a-latm" -> "AAC"
            "audio/ac3" -> "AC3"
            "audio/eac3" -> "E-AC3"
            "audio/vnd.dts", "audio/vnd.dts.hd" -> "DTS"
            "audio/true-hd" -> "TrueHD"
            "audio/opus" -> "Opus"
            "audio/vorbis" -> "Vorbis"
            else -> ""
        }
        return name + extra + if (codec.isNotEmpty()) " ($codec)" else ""
    }

    /** Lê as faixas do arquivo. Devolve null se não conseguir abrir. */
    fun inspect(ctx: Context, uri: Uri): Info? {
        val ex = MediaExtractor()
        try {
            ctx.contentResolver.openFileDescriptor(uri, "r")?.use { ex.setDataSource(it.fileDescriptor) }
                ?: return null
            var v = -1
            var vMime = ""
            val audios = mutableListOf<Audio>()
            var n = 1
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && v < 0) {
                    v = i
                    vMime = mime
                } else if (mime.startsWith("audio/")) {
                    audios.add(Audio(i, label(f, n++), mime == AUDIO_OK))
                }
            }
            if (v < 0) return null
            return Info(v, vMime in VIDEO_OK, vMime, audios)
        } catch (e: Exception) {
            return null
        } finally {
            ex.release()
        }
    }

    /**
     * Cria [out] (MP4) com o vídeo e a faixa de áudio [audioTrack] (ou só vídeo, se null).
     * Devolve false se foi cancelado. Lança exceção em caso de erro.
     */
    fun remux(
        ctx: Context,
        uri: Uri,
        info: Info,
        audioTrack: Int?,
        out: File,
        cancelled: () -> Boolean,
        onProgress: (Int) -> Unit
    ): Boolean {
        val ex = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: error("não abriu")
            val total = pfd.use {
                ex.setDataSource(it.fileDescriptor)
                it.statSize
            }

            muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val vFormat = ex.getTrackFormat(info.videoTrack)
            if (vFormat.containsKey("rotation-degrees")) {
                muxer.setOrientationHint(vFormat.getInteger("rotation-degrees"))
            }
            ex.selectTrack(info.videoTrack)
            val vOut = muxer.addTrack(vFormat)
            var aOut = -1
            if (audioTrack != null) {
                ex.selectTrack(audioTrack)
                aOut = muxer.addTrack(ex.getTrackFormat(audioTrack))
            }
            muxer.start()
            started = true

            val buf = ByteBuffer.allocateDirect(8 * 1024 * 1024)
            val bi = MediaCodec.BufferInfo()
            var read = 0L
            var lastPct = -1
            while (true) {
                if (cancelled()) return false
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                val track = ex.sampleTrackIndex
                val flags = if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0)
                    MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                bi.set(0, size, ex.sampleTime.coerceAtLeast(0L), flags)
                muxer.writeSampleData(if (track == info.videoTrack) vOut else aOut, buf, bi)
                read += size
                if (total > 0) {
                    val pct = (read * 100 / total).toInt().coerceIn(0, 99)
                    if (pct != lastPct) {
                        lastPct = pct
                        onProgress(pct)
                    }
                }
                ex.advance()
            }
            onProgress(100)
            return true
        } finally {
            try {
                if (started) muxer?.stop()
            } catch (_: Exception) {
            }
            try {
                muxer?.release()
            } catch (_: Exception) {
            }
            ex.release()
        }
    }
}
