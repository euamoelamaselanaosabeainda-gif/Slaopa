package com.cinemacast

import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.widget.ImageViewCompat
import android.content.res.ColorStateList
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.MediaSeekOptions
import com.google.android.gms.cast.MediaStatus
import com.google.android.gms.cast.MediaTrack
import com.google.android.gms.cast.TextTrackStyle
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import com.google.android.gms.cast.framework.media.RemoteMediaClient
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.Chip
import com.google.android.material.radiobutton.MaterialRadioButton
import com.google.android.material.slider.Slider
import com.google.android.material.snackbar.Snackbar
import fi.iki.elonen.NanoHTTPD
import java.io.File
import java.net.Inet4Address
import java.util.Locale

@androidx.annotation.OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private lateinit var castContext: CastContext
    private lateinit var prefs: SharedPreferences

    private lateinit var rootView: View
    private lateinit var scroll: View
    private lateinit var route: MediaRouteButton
    private lateinit var tvTitle: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvCastLabel: TextView
    private lateinit var timeCur: TextView
    private lateinit var timeTotal: TextView
    private lateinit var slider: Slider
    private lateinit var btnPlay: MaterialButton
    private lateinit var btnBack: MaterialButton
    private lateinit var btnFwd: MaterialButton
    private lateinit var btnStop: MaterialButton
    private lateinit var btnRepeat: MaterialButton
    private lateinit var ovRepeat: ImageButton
    private lateinit var btnSubs: MaterialButton
    private lateinit var btnAudio: MaterialButton
    private lateinit var castCard: View
    private lateinit var videoCard: MaterialCardView
    private lateinit var videoFrame: AspectRatioFrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var emptyState: View
    private lateinit var castOverlay: View
    private lateinit var topBar: View
    private lateinit var ovAudio: ImageButton
    private lateinit var ovFull: ImageButton
    private lateinit var fullHost: FrameLayout

    // servidor (para a TV)
    private var server: FileServer? = null
    private var baseUrl: String? = null
    private var serverIp: String? = null
    private var mediaId = 0L
    private var mediaExt = "mp4"

    // repetir ao terminar
    private var repeat = false
    private var restarting = false

    // filme e player local
    private var player: ExoPlayer? = null
    private var pickedUri: Uri? = null
    private var movieName: String = ""
    private var mime: String = "video/mp4"
    private var pos = 0L
    private var play = true
    private var savedParams: TrackSelectionParameters? = null

    // legendas externas
    private val extSubs = mutableListOf<ExtSub>()
    private var nextSubId = 1L

    // Cast
    private var attached: RemoteMediaClient? = null
    private var dragging = false
    private var castTextId: Long? = null
    private var castAudioId: Long? = null
    private var lastCastPos = -1L

    // aparência das legendas
    private var subSize = 1
    private var subColor = 0
    private var subBg = 1
    private val sizeFractions = floatArrayOf(0.05f, 0.066f, 0.085f)
    private val castScales = floatArrayOf(0.8f, 1.0f, 1.4f)
    private val textColors = intArrayOf(Color.WHITE, Color.rgb(255, 235, 59))
    private val bgColors = intArrayOf(Color.TRANSPARENT, Color.argb(150, 0, 0, 0), Color.BLACK)

    private var fullscreen = false

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onPicked(uri)
    }

    private val subPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) addSubtitle(uri)
    }

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            setFullscreen(false)
        }
    }

    private val progressListener = RemoteMediaClient.ProgressListener { progress, duration ->
        updateProgress(progress, duration)
    }

    private val clientCallback = object : RemoteMediaClient.Callback() {
        override fun onStatusUpdated() {
            handleCastStatus()
            updatePlayIcon()
            updateButtons()
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onTracksChanged(tracks: Tracks) {
            updateButtons()
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            playerView.keepScreenOn = isPlaying
        }

        override fun onPlayerError(error: PlaybackException) {
            msg("Não foi possível reproduzir este vídeo neste celular")
        }
    }

    private val sessionListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarted(s: CastSession, id: String) {
            onCastStarted()
        }
        override fun onSessionStarting(s: CastSession) {}
        override fun onSessionStartFailed(s: CastSession, error: Int) {
            tvStatus.text = "Falha ao conectar na TV (código $error)"
        }
        override fun onSessionEnding(s: CastSession) {
            lastCastPos = s.remoteMediaClient?.approximateStreamPosition ?: -1L
        }
        override fun onSessionEnded(s: CastSession, error: Int) {
            detach()
            castAudioId = null
            if (lastCastPos >= 0L) {
                pos = lastCastPos
                player?.seekTo(lastCastPos)
            }
            lastCastPos = -1L
            refreshMode()
            tvStatus.text = "Desconectado da TV"
        }
        override fun onSessionResuming(s: CastSession, id: String) {}
        override fun onSessionResumed(s: CastSession, wasSuspended: Boolean) {
            player?.pause()
            attach()
            refreshMode()
        }
        override fun onSessionResumeFailed(s: CastSession, error: Int) {}
        override fun onSessionSuspended(s: CastSession, reason: Int) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        castContext = CastContext.getSharedInstance(this)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("cinema", MODE_PRIVATE)
        subSize = prefs.getInt("sub_size", 1).coerceIn(0, 2)
        subColor = prefs.getInt("sub_color", 0).coerceIn(0, 1)
        subBg = prefs.getInt("sub_bg", 1).coerceIn(0, 2)
        repeat = prefs.getBoolean("repeat", false)

        rootView = findViewById(R.id.root)
        scroll = findViewById(R.id.scroll)
        route = findViewById(R.id.route)
        tvTitle = findViewById(R.id.tvTitle)
        tvStatus = findViewById(R.id.tvStatus)
        tvCastLabel = findViewById(R.id.tvCastLabel)
        timeCur = findViewById(R.id.timeCur)
        timeTotal = findViewById(R.id.timeTotal)
        slider = findViewById(R.id.slider)
        btnPlay = findViewById(R.id.btnPlay)
        btnBack = findViewById(R.id.btnBack)
        btnFwd = findViewById(R.id.btnFwd)
        btnStop = findViewById(R.id.btnStop)
        btnRepeat = findViewById(R.id.btnRepeat)
        ovRepeat = findViewById(R.id.ovRepeat)
        btnSubs = findViewById(R.id.btnSubs)
        btnAudio = findViewById(R.id.btnAudio)
        castCard = findViewById(R.id.playerCard)
        videoCard = findViewById(R.id.videoCard)
        videoFrame = findViewById(R.id.videoFrame)
        playerView = findViewById(R.id.playerView)
        emptyState = findViewById(R.id.emptyState)
        castOverlay = findViewById(R.id.castOverlay)
        topBar = findViewById(R.id.topBar)
        ovAudio = findViewById(R.id.ovAudio)
        ovFull = findViewById(R.id.ovFull)
        fullHost = findViewById(R.id.fullHost)

        findViewById<TextView>(R.id.tvBrand).text = SpannableString("CinemaCast").apply {
            setSpan(
                ForegroundColorSpan(ContextCompat.getColor(this@MainActivity, R.color.primary)),
                6, 10, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }

        WindowCompat.setDecorFitsSystemWindows(window, false)
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        onBackPressedDispatcher.addCallback(this, backCallback)

        videoFrame.setAspectRatio(16f / 9f)
        playerView.setControllerVisibilityListener(
            PlayerView.ControllerVisibilityListener { v ->
                topBar.visibility =
                    if (v == View.VISIBLE && pickedUri != null && !casting()) View.VISIBLE else View.GONE
            }
        )

        CastButtonFactory.setUpMediaRouteButton(applicationContext, route)
        route.setAlwaysVisible(true)

        val pick = View.OnClickListener { picker.launch(PICK_TYPES) }
        findViewById<View>(R.id.btnPick).setOnClickListener(pick)
        findViewById<View>(R.id.btnPickEmpty).setOnClickListener(pick)
        btnSubs.setOnClickListener { showSubtitlesSheet() }
        findViewById<View>(R.id.ovSubs).setOnClickListener { showSubtitlesSheet() }
        btnAudio.setOnClickListener { showAudioSheet() }
        ovAudio.setOnClickListener { showAudioSheet() }
        ovFull.setOnClickListener { setFullscreen(!fullscreen) }

        btnPlay.setOnClickListener {
            val r = remote() ?: return@setOnClickListener
            if (castFinished(r)) {
                // o filme acabou: começa de novo
                loadOnCast(0L)
            } else {
                r.togglePlayback()
            }
        }
        btnRepeat.setOnClickListener { toggleRepeat() }
        ovRepeat.setOnClickListener { toggleRepeat() }
        updateRepeatUi()
        btnBack.setOnClickListener { seekBy(-10_000) }
        btnFwd.setOnClickListener { seekBy(10_000) }
        btnStop.setOnClickListener { castContext.sessionManager.endCurrentSession(true) }

        slider.addOnChangeListener { _, value, fromUser ->
            if (fromUser) timeCur.text = fmt(value.toLong())
        }
        slider.addOnSliderTouchListener(object : Slider.OnSliderTouchListener {
            override fun onStartTrackingTouch(s: Slider) { dragging = true }
            override fun onStopTrackingTouch(s: Slider) {
                dragging = false
                seekTo(s.value.toLong())
            }
        })

        setControls(false)
        refreshMode()
    }

    override fun onStart() {
        super.onStart()
        buildPlayer()
        refreshMode()
    }

    override fun onResume() {
        super.onResume()
        castContext.sessionManager.addSessionManagerListener(sessionListener, CastSession::class.java)
        attach()
        refreshMode()
    }

    override fun onPause() {
        castContext.sessionManager.removeSessionManagerListener(sessionListener, CastSession::class.java)
        detach()
        super.onPause()
    }

    override fun onStop() {
        releasePlayer()
        super.onStop()
    }

    override fun onDestroy() {
        server?.stop()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ util

    private fun msg(text: String) {
        Snackbar.make(rootView, text, Snackbar.LENGTH_SHORT).show()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun remote() = castContext.sessionManager.currentCastSession?.remoteMediaClient

    private fun casting(): Boolean = castContext.sessionManager.currentCastSession?.isConnected == true

    private fun fmt(ms: Long): String {
        val t = ms / 1000
        val h = t / 3600
        val m = (t % 3600) / 60
        val s = t % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    }

    private fun queryNameAndSize(uri: Uri): Pair<String?, Long> {
        var name: String? = null
        var size = 0L
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val s = c.getColumnIndex(OpenableColumns.SIZE)
                if (n >= 0) name = c.getString(n)
                if (s >= 0) size = c.getLong(s)
            }
        }
        return Pair(name, size)
    }

    private fun localIp(): String? {
        val cm = getSystemService(ConnectivityManager::class.java)
        val lp = cm.getLinkProperties(cm.activeNetwork) ?: return null
        return lp.linkAddresses
            .map { it.address }
            .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
            ?.hostAddress
    }

    // ------------------------------------------------------------------ estado da tela

    /** Ajusta o que aparece na tela: vídeo local, aviso de transmissão ou estado vazio. */
    private fun refreshMode() {
        val has = pickedUri != null
        val isCasting = casting()
        emptyState.visibility = if (has) View.GONE else View.VISIBLE
        castOverlay.visibility = if (has && isCasting) View.VISIBLE else View.GONE
        castCard.visibility = if (isCasting) View.VISIBLE else View.GONE
        playerView.useController = has && !isCasting
        if (isCasting) {
            if (fullscreen) setFullscreen(false)
            topBar.visibility = View.GONE
            val dev = castContext.sessionManager.currentCastSession?.castDevice?.friendlyName ?: "TV"
            tvCastLabel.text = "Transmitindo em $dev"
        }
        updateButtons()
    }

    private fun updateButtons() {
        val has = pickedUri != null
        btnSubs.visibility = if (has) View.VISIBLE else View.GONE
        val showAudio = has && (audioCount() > 1 || castAudioTracks().size > 1)
        btnAudio.visibility = if (showAudio) View.VISIBLE else View.GONE
        ovAudio.visibility = if (showAudio) View.VISIBLE else View.GONE
    }

    private fun setFullscreen(on: Boolean) {
        if (on == fullscreen) return
        fullscreen = on
        (videoFrame.parent as? ViewGroup)?.removeView(videoFrame)
        val ctrl = WindowInsetsControllerCompat(window, window.decorView)
        if (on) {
            videoFrame.setAspectRatio(0f)
            fullHost.addView(
                videoFrame,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
            fullHost.visibility = View.VISIBLE
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            ctrl.hide(WindowInsetsCompat.Type.systemBars())
            ctrl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            fullHost.visibility = View.GONE
            videoFrame.setAspectRatio(16f / 9f)
            videoCard.addView(
                videoFrame, 0,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            )
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            ctrl.show(WindowInsetsCompat.Type.systemBars())
        }
        ovFull.setImageResource(if (on) R.drawable.ic_fullscreen_exit else R.drawable.ic_fullscreen)
        backCallback.isEnabled = on
    }

    // ------------------------------------------------------------------ escolher filme / servidor

    private fun onPicked(uri: Uri) {
        releasePlayer()
        val (name, size) = queryNameAndSize(uri)
        movieName = name ?: "Filme"
        mediaExt = movieName.substringAfterLast('.', "").lowercase().takeIf { it.length in 2..5 } ?: "mp4"
        mime = guessMime(mediaExt, contentResolver.getType(uri))
        pickedUri = uri
        restarting = false
        pos = 0L
        play = true
        savedParams = null
        extSubs.clear()
        server?.subs?.clear()
        castTextId = null
        castAudioId = null

        tvTitle.text = movieName
        tvTitle.visibility = View.VISIBLE
        startServer(uri, size)

        buildPlayer()
        refreshMode()
        if (casting()) {
            player?.pause()
            loadOnCast(0L)
        }
    }

    /**
     * O servidor é criado uma vez e reaproveitado: ao trocar de filme só mudamos a fonte e o
     * endereço (/video/ID.ext). Assim a TV nunca recebe o endereço do filme anterior.
     */
    private fun startServer(uri: Uri, size: Long) {
        val ip = localIp()
        if (ip == null) {
            server?.stop()
            server = null
            baseUrl = null
            serverIp = null
            tvStatus.text = "Sem Wi-Fi: dá para assistir aqui no celular, mas não para transmitir para a TV."
            return
        }
        try {
            var s = server
            if (s == null || !s.isAlive || serverIp != ip) {
                s?.stop()
                s = FileServer(this, PORT)
                s.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
                server = s
                serverIp = ip
                baseUrl = "http://$ip:$PORT"
            }
            mediaId++
            s.setMedia(uri, mime, size, "/video/$mediaId.$mediaExt")
            tvStatus.text = "Pronto. Assista aqui ou toque no ícone de transmitir para ver na TV."
        } catch (e: Exception) {
            server = null
            baseUrl = null
            serverIp = null
            tvStatus.text = "Não foi possível preparar a transmissão para a TV."
        }
    }

    /** Descobre o tipo do vídeo pela extensão (a galeria costuma errar em MKV, AVI, TS...). */
    private fun guessMime(ext: String, resolverType: String?): String = when (ext) {
        "mkv", "mk3d" -> "video/x-matroska"
        "mp4", "m4v", "mov" -> "video/mp4"
        "webm" -> "video/webm"
        "avi" -> "video/x-msvideo"
        "ts", "m2ts", "mts" -> "video/mp2t"
        "3gp" -> "video/3gpp"
        "wmv" -> "video/x-ms-wmv"
        "flv" -> "video/x-flv"
        "mpg", "mpeg" -> "video/mpeg"
        else -> resolverType?.takeIf { it.startsWith("video/") } ?: "video/mp4"
    }

    // ------------------------------------------------------------------ repetir

    private fun toggleRepeat() {
        repeat = !repeat
        prefs.edit().putBoolean("repeat", repeat).apply()
        player?.repeatMode = if (repeat) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        updateRepeatUi()
        msg(if (repeat) "Repetir ligado" else "Repetir desligado")
    }

    private fun updateRepeatUi() {
        val color = ContextCompat.getColor(this, if (repeat) R.color.primary else R.color.muted)
        btnRepeat.text = if (repeat) "Repetir: ligado" else "Repetir: desligado"
        btnRepeat.setIconTintResource(if (repeat) R.color.primary else R.color.muted)
        btnRepeat.setTextColor(color)
        ImageViewCompat.setImageTintList(
            ovRepeat,
            ColorStateList.valueOf(if (repeat) color else Color.WHITE)
        )
    }

    private fun castFinished(r: RemoteMediaClient): Boolean {
        val st = r.mediaStatus ?: return false
        return st.playerState == MediaStatus.PLAYER_STATE_IDLE &&
            st.idleReason == MediaStatus.IDLE_REASON_FINISHED
    }

    /** Reage ao estado da TV: repete quando acaba (se ligado) e avisa quando há erro. */
    private fun handleCastStatus() {
        val r = remote() ?: return
        val st = r.mediaStatus ?: return
        if (st.playerState == MediaStatus.PLAYER_STATE_IDLE) {
            when (st.idleReason) {
                MediaStatus.IDLE_REASON_FINISHED -> {
                    if (repeat && !restarting) {
                        restarting = true
                        loadOnCast(0L)
                    }
                }
                MediaStatus.IDLE_REASON_ERROR -> {
                    tvStatus.text = "A TV não conseguiu reproduzir este arquivo."
                    msg("A TV não aceitou este formato. Tente MP4, ou assista pelo celular.")
                }
            }
        } else {
            restarting = false
        }
    }

    // ------------------------------------------------------------------ player local

    private fun buildItem(u: Uri): MediaItem {
        val defaultId = extSubs.lastOrNull()?.id
        val subs = extSubs.map { s ->
            MediaItem.SubtitleConfiguration.Builder(s.uri)
                .setMimeType(s.mime)
                .setLabel(s.name)
                .setSelectionFlags(if (defaultId == s.id) C.SELECTION_FLAG_DEFAULT else 0)
                .build()
        }
        return MediaItem.Builder().setUri(u).setSubtitleConfigurations(subs).build()
    }

    private fun buildPlayer() {
        releasePlayer()
        val u = pickedUri ?: return
        val p = ExoPlayer.Builder(this, DefaultRenderersFactory(this).setEnableDecoderFallback(true)).build()
        p.addListener(playerListener)
        p.repeatMode = if (repeat) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        savedParams?.let { p.trackSelectionParameters = it }
        p.setMediaItem(buildItem(u), pos)
        p.playWhenReady = play && !casting()
        p.prepare()
        playerView.player = p
        player = p
        applySubStyle()
    }

    private fun releasePlayer() {
        player?.let {
            pos = it.currentPosition
            play = it.playWhenReady
            savedParams = it.trackSelectionParameters
            it.removeListener(playerListener)
            it.release()
        }
        player = null
        playerView.player = null
    }

    // ------------------------------------------------------------------ faixas (legenda e áudio)

    private fun trackLabel(f: Format, n: Int, fallback: String): String {
        val lang = f.language
            ?.takeIf { it.isNotBlank() && it != C.LANGUAGE_UNDETERMINED }
            ?.let { Locale.forLanguageTag(it).getDisplayLanguage(Locale("pt", "BR")) }
            ?.takeIf { it.isNotBlank() }
            ?.replaceFirstChar { c -> c.uppercase() }
        val name = f.label?.takeIf { it.isNotBlank() } ?: lang ?: "$fallback $n"
        val extra = when {
            f.channelCount >= 8 -> "7.1"
            f.channelCount >= 6 -> "5.1"
            else -> null
        }
        return if (extra != null) "$name · $extra" else name
    }

    private fun audioCount(): Int {
        val p = player ?: return 0
        return p.currentTracks.groups
            .filter { it.type == C.TRACK_TYPE_AUDIO }
            .sumOf { g -> (0 until g.length).count { g.isTrackSupported(it) } }
    }

    private fun selectText(group: Tracks.Group?, index: Int) {
        val p = player ?: return
        val b = p.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_TEXT)
        if (group == null) {
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        } else {
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            b.setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, index))
        }
        p.trackSelectionParameters = b.build()
    }

    private fun selectAudio(group: Tracks.Group, index: Int) {
        val p = player ?: return
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, index))
            .build()
    }

    private fun radio(group: RadioGroup, text: String, checked: Boolean, onClick: () -> Unit) {
        val rb = MaterialRadioButton(this)
        rb.id = View.generateViewId()
        rb.text = text
        rb.setTextColor(ContextCompat.getColor(this, R.color.on_surface))
        rb.textSize = 16f
        rb.setPadding(dp(8), dp(10), dp(8), dp(10))
        rb.isChecked = checked
        rb.setOnClickListener { onClick() }
        group.addView(rb, RadioGroup.LayoutParams(RadioGroup.LayoutParams.MATCH_PARENT, RadioGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun sheet(layout: Int): Pair<BottomSheetDialog, View> {
        val dialog = BottomSheetDialog(this)
        val v = layoutInflater.inflate(layout, null)
        dialog.setContentView(v)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dialog.behavior.skipCollapsed = true
        return Pair(dialog, v)
    }

    private fun showSubtitlesSheet() {
        if (pickedUri == null) {
            msg("Escolha o filme primeiro")
            return
        }
        val (dialog, v) = sheet(R.layout.sheet_subtitles)
        val group = v.findViewById<RadioGroup>(R.id.subTracks)
        val note = v.findViewById<TextView>(R.id.subNote)

        if (casting()) {
            radio(group, "Desativadas", castTextId == null) {
                castTextId = null
                applyCastTracks()
                dialog.dismiss()
            }
            extSubs.filter { it.path != null }.forEach { s ->
                radio(group, s.name, castTextId == s.id) {
                    castTextId = s.id
                    applyCastTracks()
                    dialog.dismiss()
                }
            }
            note.text = "Na TV funcionam legendas de arquivo (.srt e .vtt). As legendas embutidas no filme aparecem só no celular."
            note.visibility = View.VISIBLE
        } else {
            val textGroups = player?.currentTracks?.groups.orEmpty().filter { it.type == C.TRACK_TYPE_TEXT }
            radio(group, "Desativadas", textGroups.none { it.isSelected }) {
                selectText(null, 0)
                dialog.dismiss()
            }
            var n = 1
            textGroups.forEach { g ->
                for (i in 0 until g.length) {
                    if (!g.isTrackSupported(i)) continue
                    val label = trackLabel(g.getTrackFormat(i), n++, "Legenda")
                    radio(group, label, g.isTrackSelected(i)) {
                        selectText(g, i)
                        dialog.dismiss()
                    }
                }
            }
            if (group.childCount == 1) {
                note.text = "Este filme não tem legendas embutidas. Carregue um arquivo abaixo."
                note.visibility = View.VISIBLE
            }
        }

        v.findViewById<View>(R.id.btnLoadSub).setOnClickListener {
            dialog.dismiss()
            subPicker.launch(arrayOf("*/*"))
        }

        bindChips(v, listOf(R.id.chipSizeS, R.id.chipSizeM, R.id.chipSizeL), subSize) {
            subSize = it
            saveSubStyle()
        }
        bindChips(v, listOf(R.id.chipColW, R.id.chipColY), subColor) {
            subColor = it
            saveSubStyle()
        }
        bindChips(v, listOf(R.id.chipBgN, R.id.chipBgT, R.id.chipBgS), subBg) {
            subBg = it
            saveSubStyle()
        }
        dialog.show()
    }

    private fun bindChips(v: View, ids: List<Int>, selected: Int, onSelect: (Int) -> Unit) {
        ids.forEachIndexed { idx, id ->
            val chip = v.findViewById<Chip>(id)
            chip.isChecked = idx == selected
            chip.setOnCheckedChangeListener { _, checked -> if (checked) onSelect(idx) }
        }
    }

    private fun saveSubStyle() {
        prefs.edit()
            .putInt("sub_size", subSize)
            .putInt("sub_color", subColor)
            .putInt("sub_bg", subBg)
            .apply()
        applySubStyle()
    }

    private fun applySubStyle() {
        playerView.subtitleView?.apply {
            setApplyEmbeddedStyles(false)
            setApplyEmbeddedFontSizes(false)
            setFractionalTextSize(sizeFractions[subSize])
            setStyle(
                CaptionStyleCompat(
                    textColors[subColor],
                    bgColors[subBg],
                    Color.TRANSPARENT,
                    CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                    Color.BLACK,
                    null
                )
            )
        }
        applyCastStyle()
    }

    private fun applyCastStyle() {
        val r = remote() ?: return
        val st = TextTrackStyle()
        st.setFontScale(castScales[subSize])
        st.setForegroundColor(textColors[subColor])
        st.setBackgroundColor(bgColors[subBg])
        st.setEdgeType(TextTrackStyle.EDGE_TYPE_OUTLINE)
        st.setEdgeColor(Color.BLACK)
        r.setTextTrackStyle(st)
    }

    private fun showAudioSheet() {
        val (dialog, v) = sheet(R.layout.sheet_audio)
        val group = v.findViewById<RadioGroup>(R.id.audioTracks)
        val note = v.findViewById<TextView>(R.id.audioNote)

        if (casting()) {
            val tracks = castAudioTracks()
            if (tracks.size > 1) {
                val active = remote()?.mediaStatus?.activeTrackIds
                tracks.forEachIndexed { i, t ->
                    val label = t.name?.takeIf { it.isNotBlank() }
                        ?: t.language?.takeIf { it.isNotBlank() }
                            ?.let { Locale.forLanguageTag(it).getDisplayLanguage(Locale("pt", "BR")) }
                            ?.replaceFirstChar { c -> c.uppercase() }
                        ?: "Áudio ${i + 1}"
                    radio(group, label, active?.contains(t.id) == true) {
                        castAudioId = t.id
                        applyCastTracks()
                        dialog.dismiss()
                    }
                }
            } else {
                note.text = "A TV não permite trocar o áudio deste arquivo. Para escolher o idioma, assista no celular."
                note.visibility = View.VISIBLE
            }
        } else {
            val audioGroups = player?.currentTracks?.groups.orEmpty().filter { it.type == C.TRACK_TYPE_AUDIO }
            var n = 1
            audioGroups.forEach { g ->
                for (i in 0 until g.length) {
                    if (!g.isTrackSupported(i)) continue
                    val label = trackLabel(g.getTrackFormat(i), n++, "Áudio")
                    radio(group, label, g.isTrackSelected(i)) {
                        selectAudio(g, i)
                        dialog.dismiss()
                    }
                }
            }
        }
        dialog.show()
    }

    // ------------------------------------------------------------------ legendas externas

    private fun addSubtitle(uri: Uri) {
        if (pickedUri == null) {
            msg("Escolha o filme primeiro")
            return
        }
        val fileName = queryNameAndSize(uri).first ?: "Legenda"
        val ext = fileName.substringAfterLast('.', "").lowercase()
        val subMime = when (ext) {
            "srt" -> MimeTypes.APPLICATION_SUBRIP
            "vtt" -> MimeTypes.TEXT_VTT
            "ass", "ssa" -> MimeTypes.TEXT_SSA
            else -> null
        }
        if (subMime == null) {
            msg("Formato não suportado. Use .srt, .vtt ou .ass")
            return
        }
        val bytes = try {
            contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (e: Exception) {
            null
        }
        if (bytes == null) {
            msg("Não consegui ler a legenda")
            return
        }
        val text = Subs.decode(bytes)
        val id = nextSubId++
        val file = File(cacheDir, "sub_$id.$ext")
        file.writeText(text, Charsets.UTF_8)

        var path: String? = null
        if (ext == "srt" || ext == "vtt") {
            path = "/sub/$id.vtt"
            server?.subs?.put(path, if (ext == "srt") Subs.srtToVtt(text) else text)
        }
        extSubs.add(ExtSub(id, fileName.substringBeforeLast('.'), Uri.fromFile(file), subMime, path))

        // aplica no player local: recarrega o filme na mesma posição com a nova legenda ativa
        player?.let { p ->
            val at = p.currentPosition
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                .build()
            p.setMediaItem(buildItem(pickedUri!!), at)
            p.prepare()
        }

        if (path != null) castTextId = id
        if (casting()) {
            if (path != null) {
                loadOnCast(remote()?.approximateStreamPosition ?: 0L)
            } else {
                msg("Legenda .ass não funciona na TV; use .srt ou .vtt")
            }
        } else {
            msg("Legenda carregada")
        }
    }

    // ------------------------------------------------------------------ Cast

    private fun onCastStarted() {
        player?.let {
            pos = it.currentPosition
            it.pause()
        }
        castAudioId = null
        attach()
        refreshMode()
        loadOnCast(pos)
    }

    private fun attach() {
        val r = remote()
        if (r === attached) return
        detach()
        if (r != null) {
            r.registerCallback(clientCallback)
            r.addProgressListener(progressListener, 1000)
            attached = r
            setControls(true)
            updatePlayIcon()
        }
    }

    private fun detach() {
        attached?.let {
            it.unregisterCallback(clientCallback)
            it.removeProgressListener(progressListener)
        }
        attached = null
        setControls(false)
    }

    private fun setControls(on: Boolean) {
        listOf<View>(btnPlay, btnBack, btnFwd, btnStop, btnRepeat, slider).forEach { it.isEnabled = on }
        castCard.alpha = if (on) 1f else 0.5f
    }

    private fun updatePlayIcon() {
        val r = remote()
        val playing = r?.isPlaying == true
        val icon = when {
            r != null && castFinished(r) -> R.drawable.ic_replay
            playing -> R.drawable.ic_pause
            else -> R.drawable.ic_play
        }
        btnPlay.setIconResource(icon)
    }

    private fun updateProgress(progress: Long, duration: Long) {
        if (duration <= 0L || dragging) return
        try {
            if (slider.valueTo != duration.toFloat()) {
                slider.value = 0f
                slider.valueTo = duration.toFloat()
            }
            slider.value = progress.coerceIn(0L, duration).toFloat()
        } catch (_: IllegalStateException) {
        }
        timeCur.text = fmt(progress)
        timeTotal.text = fmt(duration)
    }

    private fun seekBy(deltaMs: Long) {
        val r = remote() ?: return
        seekTo((r.approximateStreamPosition + deltaMs).coerceAtLeast(0L))
    }

    private fun seekTo(posMs: Long) {
        remote()?.seek(MediaSeekOptions.Builder().setPosition(posMs).build())
    }

    private fun castAudioTracks(): List<MediaTrack> =
        remote()?.mediaInfo?.mediaTracks.orEmpty().filter { it.type == MediaTrack.TYPE_AUDIO }

    /** Manda para a TV a faixa de legenda e a de áudio escolhidas. */
    private fun applyCastTracks() {
        val r = remote() ?: return
        val audioIds = castAudioTracks().map { it.id }
        val keepAudio = castAudioId ?: r.mediaStatus?.activeTrackIds?.firstOrNull { it in audioIds }
        val ids = mutableListOf<Long>()
        castTextId?.let { ids.add(it) }
        keepAudio?.let { ids.add(it) }
        r.setActiveMediaTracks(ids.toLongArray())
    }

    private fun loadOnCast(startMs: Long = 0L) {
        val base = baseUrl
        val path = server?.mediaPath
        if (base == null || path == null) {
            msg("Não foi possível enviar o filme para a TV")
            return
        }
        val session = castContext.sessionManager.currentCastSession ?: return
        val r = session.remoteMediaClient ?: return
        val meta = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE).apply {
            putString(MediaMetadata.KEY_TITLE, movieName)
        }
        val tracks = extSubs.filter { it.path != null }.map { s ->
            MediaTrack.Builder(s.id, MediaTrack.TYPE_TEXT)
                .setContentId(base + s.path)
                .setContentType("text/vtt")
                .setSubtype(MediaTrack.SUBTYPE_SUBTITLES)
                .setName(s.name)
                .setLanguage("und")
                .build()
        }
        val infoBuilder = MediaInfo.Builder(base + path)
            .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
            .setContentType(mime)
            .setMetadata(meta)
        if (tracks.isNotEmpty()) infoBuilder.setMediaTracks(tracks)

        val req = MediaLoadRequestData.Builder()
            .setMediaInfo(infoBuilder.build())
            .setAutoplay(true)
            .setCurrentTime(startMs)
        castTextId?.let { req.setActiveTrackIds(longArrayOf(it)) }
        r.load(req.build()).setResultCallback { res ->
            if (!res.status.isSuccess) {
                msg("A TV não conseguiu abrir este filme")
            }
        }
        applyCastStyle()
        slider.value = 0f
        timeCur.text = fmt(startMs)

        val dev = session.castDevice?.friendlyName ?: "TV"
        tvStatus.text = "Transmitindo em $dev"
        tvCastLabel.text = "Transmitindo em $dev"
    }

    companion object {
        private const val PORT = 8765
        private val PICK_TYPES = arrayOf(
            "video/*",
            "application/x-matroska",
            "application/octet-stream"
        )
    }
}
