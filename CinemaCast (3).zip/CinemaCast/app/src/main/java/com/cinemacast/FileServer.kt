package com.cinemacast

import android.content.Context
import android.net.Uri
import fi.iki.elonen.NanoHTTPD
import java.io.FileInputStream
import java.io.FilterInputStream
import java.util.concurrent.ConcurrentHashMap

/**
 * Serve pela rede Wi-Fi o vídeo escolhido na galeria (com suporte a Range, para pular no filme)
 * e as legendas em WebVTT (/sub/ID.vtt) para a TV.
 *
 * O servidor fica sempre ligado; ao escolher outro filme só trocamos a fonte ([setMedia]) e o
 * endereço do vídeo muda a cada filme (/video/ID.ext), para a TV nunca reaproveitar o antigo.
 */
class FileServer(private val ctx: Context, port: Int) : NanoHTTPD(port) {

    @Volatile private var src: Uri? = null
    @Volatile private var mimeType: String = "video/mp4"
    @Volatile private var length: Long = 0L

    /** caminho atual do vídeo, ex.: /video/3.mkv */
    @Volatile var mediaPath: String = "/video/0.mp4"
        private set

    /** caminho (ex.: /sub/3.vtt) -> conteúdo WebVTT */
    val subs = ConcurrentHashMap<String, String>()

    fun setMedia(uri: Uri, mime: String, size: Long, path: String) {
        src = uri
        mimeType = mime
        length = if (size > 0) size else sizeOf(uri)
        mediaPath = path
    }

    private fun sizeOf(uri: Uri): Long = try {
        ctx.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: 0L
    } catch (e: Exception) {
        0L
    }

    private fun cors(r: Response): Response {
        r.addHeader("Access-Control-Allow-Origin", "*")
        r.addHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
        r.addHeader("Access-Control-Allow-Headers", "Range, Content-Type")
        r.addHeader("Access-Control-Expose-Headers", "Content-Range, Accept-Ranges, Content-Length")
        return r
    }

    override fun serve(session: IHTTPSession): Response {
        if (session.method == Method.OPTIONS) {
            return cors(NanoHTTPD.newFixedLengthResponse(Response.Status.OK, MIME_PLAINTEXT, ""))
        }
        val path = session.uri
        if (path.startsWith("/sub/")) {
            val vtt = subs[path] ?: return cors(
                NanoHTTPD.newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "sem legenda")
            )
            return cors(NanoHTTPD.newFixedLengthResponse(Response.Status.OK, "text/vtt; charset=utf-8", vtt))
        }
        if (path.startsWith("/video")) {
            return cors(serveVideo(session))
        }
        return cors(NanoHTTPD.newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "não encontrado"))
    }

    private fun serveVideo(session: IHTTPSession): Response {
        val u = src ?: return NanoHTTPD.newFixedLengthResponse(
            Response.Status.NOT_FOUND, MIME_PLAINTEXT, "sem arquivo"
        )
        val mime = mimeType
        val total = length
        val range = session.headers["range"]

        var start = 0L
        var end = total - 1
        if (range != null && range.startsWith("bytes=")) {
            val parts = range.removePrefix("bytes=").substringBefore(",").split("-")
            val a = parts.getOrNull(0)?.trim()?.toLongOrNull()
            val b = parts.getOrNull(1)?.trim()?.toLongOrNull()
            if (a == null && b != null) {
                // "bytes=-N": os últimos N bytes
                start = (total - b).coerceAtLeast(0L)
            } else {
                start = a ?: 0L
                if (b != null) end = b.coerceAtMost(total - 1)
            }
        }
        if (start >= total) {
            val r = NanoHTTPD.newFixedLengthResponse(
                Response.Status.RANGE_NOT_SATISFIABLE, MIME_PLAINTEXT, ""
            )
            r.addHeader("Content-Range", "bytes */$total")
            return r
        }

        val pfd = try {
            ctx.contentResolver.openFileDescriptor(u, "r")
        } catch (e: Exception) {
            null
        } ?: return NanoHTTPD.newFixedLengthResponse(
            Response.Status.NOT_FOUND, MIME_PLAINTEXT, "nao abriu"
        )
        val fis = FileInputStream(pfd.fileDescriptor)
        fis.channel.position(start)
        val stream = object : FilterInputStream(fis) {
            override fun close() {
                try {
                    super.close()
                } finally {
                    pfd.close()
                }
            }
        }

        val len = end - start + 1
        val status = if (range != null) Response.Status.PARTIAL_CONTENT else Response.Status.OK
        val resp = NanoHTTPD.newFixedLengthResponse(status, mime, stream, len)
        resp.addHeader("Accept-Ranges", "bytes")
        if (range != null) resp.addHeader("Content-Range", "bytes $start-$end/$total")
        return resp
    }
}
